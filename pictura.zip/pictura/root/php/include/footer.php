<div id='footer'>
    <span>HEIG-VD - 2019</span>
</div>