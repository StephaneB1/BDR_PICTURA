<?php

/**
 * HEIG-VD
 * Authors: Stéphane Bottin, Robin Demarta, Simon Mattei
 * Date: 20.12.2019
 * Summary: This file prevents access to folder via the URL
 */

include_once($_SERVER['DOCUMENT_ROOT']."/php/include/func.php");
redirect(null);

?>