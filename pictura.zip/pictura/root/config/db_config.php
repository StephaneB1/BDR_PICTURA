<?php

/**
 * HEIG-VD - Mini-Projet BDR
 * 
 * Authors:     Stéphane Bottin, Robin Demarta, Simon Mattei
 * Date:        20.12.2019
 * 
 * Summary:     This class is for the MySQL database configuration
 */

//Database configuration's informations
return [
	"hostname" => "localhost",
	"port" => '',
	"database" => "PICTURA",
	"user" => "<username>",
	"password" => "<password>"
];

?>